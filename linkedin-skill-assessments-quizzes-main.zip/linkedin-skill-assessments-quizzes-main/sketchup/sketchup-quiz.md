## Sketchup

#### Q1. Which of these will NOT stretch geometry if you click it with the Move tool and move your cursor outward?

- [x] a group
- [ ] and edge
- [ ] an endpoint
- [ ] a face

#### Q2. What is needed to use the Follow Me tool?

- [x] a continuous path of edges
- [ ] a correctly oriented face
- [ ] the Push/Pull tool
- [ ] the Offset and Move tools
